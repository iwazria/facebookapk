# Facebook Page Manager (personal use)

Phone app + small online backend to publish and schedule posts on Facebook Pages **you administer**, using Meta's official Login and Pages API only.
No browser automation, no scraping, no likes/comments/friend requests, no personal-profile posting. Your Facebook password is only typed on Meta's own login page.

## 1. How it works
```
Android app --HTTPS--> your backend (must be online 24/7) --> Meta Graph API
 only a revocable        app secret, encrypted Page tokens,
 session token           publishing worker, pause flag, audit log
```
* Login: app opens `BACKEND/auth/start` in your browser -> Meta login -> `BACKEND/auth/callback` -> backend stores encrypted tokens -> returns to the app via `fbpagemgr://auth?code=...` -> app trades the one-time code (PKCE-protected) for its own session token.
* Posting now: backend calls `POST /{page-id}/feed`.
* Scheduling: Meta only accepts native scheduled times from 10 minutes to 30 days ahead. The backend holds your post, hands it to Meta (`published=false` + `scheduled_publish_time`) within `HANDOFF_MINUTES` (default 60) of the due time, or publishes at the due time if under 11 minutes remain.
* **The backend must be hosted online and always on.** If it is asleep or off, posts not yet handed to Meta will be late; posts older than `LATE_GRACE_MINUTES` (default 30) are marked Failed rather than published stale.
* Pause: stops the backend from sending anything, and tries to delete posts already scheduled at Meta (they return to the queue). Not verified: whether Meta always allows deleting scheduled posts; if one can't be cancelled the app tells you it may still publish.
* Retries: temporary errors (rate limits, Meta outages, network) retry with exponential backoff, max 5 tries. Permanent errors (expired token, no permission, rejected content) fail immediately with a readable message.

## 2. Files and where they go
```
fb-page-manager/                      <- one GitHub repo with this exact layout
  README.md
  .github/workflows/android.yml       cloud APK build (must be at repo root)
  backend/
    package.json  server.js  db.js  meta.js  .env.example  .gitignore
  android/
    settings.gradle  build.gradle  gradle.properties  .gitignore
    app/build.gradle
    app/src/main/AndroidManifest.xml
    app/src/main/java/com/example/fbpagemgr/MainActivity.java  Api.java  Store.java
```

## 3. Accounts you need
Facebook account that is admin of your Pages; Meta developer account (developers.facebook.com); a backend host with HTTPS and **persistent storage** (SQLite file) that stays awake (free tiers often sleep or wipe disks - check current terms; a small paid instance or a Fly.io volume works); a GitHub account (for the cloud APK build).

## 4. Meta app setup (screens change - follow Meta's current dashboard)
1. developers.facebook.com > My Apps > Create app. Pick the use case for managing Pages ("Manage everything on your Page" at time of writing).
2. Add permissions `pages_show_list`, `pages_manage_posts`, `pages_read_engagement`. Request nothing else.
3. App settings > Basic: copy **App ID** and **App Secret** (secret goes only in backend env vars).
4. Facebook Login settings: add **Valid OAuth Redirect URI** = `https://YOUR-BACKEND/auth/callback` (exact match).
5. If the dashboard says you must use Facebook Login for Business: create a Configuration containing those 3 permissions, and put its ID in `META_CONFIG_ID`. (Login-for-Business parameters here follow Meta's docs but are the part I could not test; if login errors, check Meta's current "Facebook Login for Business" guide.)
6. Keep the app in **Development mode**. You are the app admin, so with Standard Access you can use your own Pages without App Review. App Review / Advanced Access is needed only if other people use it.
7. Known risk: Pages owned by a Business portfolio may not show up without `business_management`. If a Page is missing from the list, add `business_management` to `META_SCOPES` (this may trigger extra review requirements).

## 5. Deploy the backend
1. Generate the encryption key (Termux, any computer, or an online Node shell):
   `node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"`
2. Create a Node (>=20) web service from the repo, root directory `backend`, build `npm install`, start `npm start`, attach a persistent disk and set `DB_PATH` to a file on it (e.g. `/data/app.db`).
3. Set env vars from `backend/.env.example`: `META_APP_ID`, `META_APP_SECRET`, `BASE_URL`, `TOKEN_ENC_KEY`. Enter them in the host's dashboard - never in files or in the app.
4. Open `https://YOUR-BACKEND/healthz` - you should see `{"ok":true}`.
5. Back in Meta, make sure the redirect URI from step 4.4 matches `BASE_URL`.

## 6. Build and install the APK from your phone
**Recommended (cloud build):** put the repo on GitHub (phone browser, "Desktop site" mode > Add file > Upload files; or use Termux + git). Repo > Actions > "Build Android APK" > Run workflow. When it finishes open the run > Artifacts > download `page-manager-apk`, unzip with your Files app, tap `app-debug.apk`, allow "install unknown apps" for that app. Play Protect may warn because it's a debug-signed personal build.
**AIDE:** open `android/` as a Gradle project. AIDE is old; this project needs Java 8 language features and a recent Android SDK (compileSdk 34), which AIDE may not support. If it fails, use the cloud build.

## 7. First run
Open app > enter backend URL > Connect with Facebook > in Meta's dialog choose the Pages to allow > tap "return to the app" if it doesn't switch automatically > pick a Page > post. Test "publish now" first, then a schedule ~30 minutes out.

## 8. Disconnecting
* Disconnect selected Page: cancels its queued/scheduled posts and deletes its stored token on the backend. Meta-side access remains until you revoke.
* Disconnect account: cancels scheduled posts, calls Meta to revoke the app's permissions (`DELETE /{user-id}/permissions`), and deletes your data.
* Refresh authorization: sign out and sign in again.

## 9. What you must configure/host yourself
Meta app + secret, redirect URI, backend host with HTTPS and persistent disk, env vars, GitHub repo for the APK build. Also yours: monitoring, backups of the SQLite file, and Meta's rules about duplicate/spammy content.

## 10. Not included in v1
Webhooks, media/photo/video posts, editing published posts, multi-user roles/approval workflow (single-user app), insights.

## 11. Honest limits
This code was written without being compiled or run against Meta (no Android SDK or network where it was produced; only the JavaScript was syntax-checked). Expect to fix small issues on first build. Unverified against live Meta: Login-for-Business parameters, deleting scheduled posts, the `is_published` field, Page-token lifetime, and rate-limit behavior. Rotate your App Secret if it is ever exposed.

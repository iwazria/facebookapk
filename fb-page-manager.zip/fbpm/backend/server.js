'use strict';
for (const k of ['META_APP_ID', 'META_APP_SECRET', 'BASE_URL', 'TOKEN_ENC_KEY']) {
  if (!process.env[k]) { console.error('Missing environment variable: ' + k); process.exit(1); }
}
const express = require('express');
const crypto = require('crypto');
const { db, enc, dec, sha, now, audit } = require('./db');
const meta = require('./meta');

const BASE = process.env.BASE_URL.replace(/\/+$/, '');
if (!BASE.startsWith('https://')) { console.error('BASE_URL must start with https://'); process.exit(1); }
const SCOPES = process.env.META_SCOPES || 'pages_show_list,pages_manage_posts,pages_read_engagement';
const CONFIG_ID = process.env.META_CONFIG_ID || '';
const HANDOFF = Math.min(Number(process.env.HANDOFF_MINUTES || 60), 60 * 24 * 29) * 60; // when to hand posts to Meta
const GRACE = Number(process.env.LATE_GRACE_MINUTES || 30) * 60;
const NATIVE_MIN = 11 * 60; // Meta needs >= 10 min lead; 1 min margin
const MAX_ATTEMPTS = 5;
const SESSION_TTL = 90 * 86400;

const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '50kb' }));
app.use((req, res, next) => {
  res.set({ 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' });
  next();
});
const ah = (fn) => (req, res, next) => fn(req, res, next).catch(next);

// Tiny in-memory rate limit for /auth/*
const hits = new Map();
app.use('/auth', (req, res, next) => {
  const k = req.ip, t = Date.now();
  const arr = (hits.get(k) || []).filter((x) => t - x < 60000);
  arr.push(t); hits.set(k, arr);
  if (arr.length > 30) return res.status(429).send('Too many requests');
  next();
});

const safeEq = (a, b) => {
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};
const pubPost = (p) => ({ id: p.id, pageId: p.page_id, message: p.message, scheduledAt: p.scheduled_at, status: p.status, error: p.error, permalink: p.permalink, attempts: p.attempts });

app.get('/healthz', (req, res) => res.json({ ok: true }));

// ---------- Sign-in ----------
app.get('/auth/start', (req, res) => {
  const challenge = String(req.query.challenge || '');
  if (!/^[A-Za-z0-9_-]{43}$/.test(challenge)) return res.status(400).send('Bad request');
  const state = crypto.randomBytes(24).toString('base64url');
  db.prepare('INSERT INTO oauth_state(state, challenge, created_at) VALUES(?,?,?)').run(state, challenge, now());
  const q = new URLSearchParams({ client_id: process.env.META_APP_ID, redirect_uri: BASE + '/auth/callback', state, response_type: 'code' });
  if (CONFIG_ID) { q.set('config_id', CONFIG_ID); q.set('override_default_response_type', 'true'); }
  else q.set('scope', SCOPES);
  res.redirect(`https://www.facebook.com/${meta.V}/dialog/oauth?${q.toString()}`);
});

app.get('/auth/callback', ah(async (req, res) => {
  db.prepare('DELETE FROM oauth_state WHERE created_at < ?').run(now() - 600);
  const st = db.prepare('SELECT * FROM oauth_state WHERE state = ?').get(String(req.query.state || ''));
  if (!st) return res.status(400).send('Invalid or expired sign-in. Go back to the app and try again.');
  db.prepare('DELETE FROM oauth_state WHERE state = ?').run(st.state);
  if (req.query.error || !req.query.code) return res.status(400).send('Sign-in was cancelled or denied. Go back to the app.');
  try {
    const short = await meta.exchangeCode(String(req.query.code), BASE + '/auth/callback');
    let userToken = short.access_token;
    try { userToken = (await meta.longLived(short.access_token)).access_token || userToken; } catch (e) { /* keep short token */ }
    const profile = await meta.me(userToken);
    const pages = (await meta.listPages(userToken)).filter((p) => p.access_token && (!p.tasks || p.tasks.some((t) => t === 'CREATE_CONTENT' || t === 'MANAGE')));
    const code = crypto.randomBytes(32).toString('base64url');
    const userId = db.transaction(() => {
      db.prepare(`INSERT INTO users(fb_user_id, name, user_token, created_at) VALUES(?,?,?,?)
        ON CONFLICT(fb_user_id) DO UPDATE SET name = excluded.name, user_token = excluded.user_token`)
        .run(profile.id, profile.name || '', enc(userToken), now());
      const uid = db.prepare('SELECT id FROM users WHERE fb_user_id = ?').get(profile.id).id;
      db.prepare('DELETE FROM pages WHERE user_id = ?').run(uid);
      const ins = db.prepare('INSERT INTO pages(user_id, page_id, name, token) VALUES(?,?,?,?)');
      for (const p of pages) ins.run(uid, p.id, p.name || '', enc(p.access_token));
      db.prepare('INSERT INTO app_codes(code_hash, user_id, challenge, created_at) VALUES(?,?,?,?)').run(sha(code), uid, st.challenge, now());
      return uid;
    })();
    audit(userId, 'connected', `${pages.length} page(s)`);
    const link = `fbpagemgr://auth?code=${code}`;
    res.type('html').send(`<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><body style="font-family:sans-serif;padding:24px"><h3>Connected</h3><p>${pages.length} Page(s) available.</p><p><a href="${link}" style="font-size:20px">Tap here to return to the app</a></p><script>location.href=${JSON.stringify(link)}</script></body>`);
  } catch (e) {
    console.error('callback failed:', e.message);
    res.status(502).send('Sign-in failed: ' + (e.message || 'unknown error'));
  }
}));

app.post('/auth/exchange', (req, res) => {
  const { code, verifier } = req.body || {};
  if (typeof code !== 'string' || typeof verifier !== 'string') return res.status(400).json({ error: 'Bad request' });
  db.prepare('DELETE FROM app_codes WHERE created_at < ?').run(now() - 300);
  const row = db.prepare('SELECT * FROM app_codes WHERE code_hash = ?').get(sha(code));
  if (!row) return res.status(400).json({ error: 'Sign-in code expired. Please try again.' });
  db.prepare('DELETE FROM app_codes WHERE code_hash = ?').run(row.code_hash);
  const challenge = crypto.createHash('sha256').update(verifier).digest('base64url');
  if (!safeEq(challenge, row.challenge)) return res.status(400).json({ error: 'Sign-in could not be verified.' });
  const session = crypto.randomBytes(32).toString('base64url');
  db.prepare('INSERT INTO sessions(token_hash, user_id, created_at) VALUES(?,?,?)').run(sha(session), row.user_id, now());
  res.json({ session });
});

function auth(req, res, next) {
  const m = /^Bearer (.+)$/.exec(req.get('authorization') || '');
  const row = m && db.prepare('SELECT user_id FROM sessions WHERE token_hash = ? AND created_at > ?').get(sha(m[1]), now() - SESSION_TTL);
  if (!row) return res.status(401).json({ error: 'Please sign in again.' });
  req.uid = row.user_id;
  next();
}

app.post('/auth/logout', auth, (req, res) => {
  db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha(req.get('authorization').slice(7)));
  res.json({ ok: true });
});

// ---------- Pages ----------
app.get('/pages', auth, (req, res) => {
  const rows = db.prepare('SELECT page_id, name, needs_reauth FROM pages WHERE user_id = ? ORDER BY name').all(req.uid);
  res.json({ pages: rows.map((r) => ({ id: r.page_id, name: r.name, needsReauth: !!r.needs_reauth })) });
});

async function cancelScheduledAtMeta(posts, pageTokenFor) {
  let ok = 0, failed = 0;
  for (const p of posts) {
    try { await meta.deletePost(p.fb_post_id, pageTokenFor(p.page_id)); ok++; } catch (e) { failed++; }
  }
  return { ok, failed };
}

app.delete('/pages/:id', auth, ah(async (req, res) => {
  const pg = db.prepare('SELECT * FROM pages WHERE user_id = ? AND page_id = ?').get(req.uid, req.params.id);
  if (!pg) return res.status(404).json({ error: 'Page not found' });
  const held = db.prepare("SELECT * FROM posts WHERE user_id = ? AND page_id = ? AND status IN ('queued','scheduled')").all(req.uid, pg.page_id);
  const sched = held.filter((p) => p.status === 'scheduled' && p.fb_post_id);
  const r = await cancelScheduledAtMeta(sched, () => dec(pg.token));
  db.prepare("UPDATE posts SET status='cancelled', error='Page disconnected', updated_at=? WHERE user_id=? AND page_id=? AND status IN ('queued','scheduled')").run(now(), req.uid, pg.page_id);
  db.prepare('DELETE FROM pages WHERE user_id = ? AND page_id = ?').run(req.uid, pg.page_id);
  audit(req.uid, 'page_disconnected', pg.page_id);
  let note = 'Page removed from this app and its stored token deleted.';
  if (r.failed) note += ` ${r.failed} post(s) already scheduled at Meta could not be cancelled; delete them in Meta Business Suite.`;
  note += ' To remove the app\'s access at Meta, use "Disconnect account" or Facebook settings > Business Integrations.';
  res.json({ ok: true, note });
}));

// ---------- Posts ----------
app.post('/posts', auth, ah(async (req, res) => {
  const { pageId, message, scheduledAt } = req.body || {};
  if (typeof pageId !== 'string' || typeof message !== 'string' || !message.trim() || message.length > 5000) return res.status(400).json({ error: 'Choose a Page and write a message (max 5000 characters).' });
  const pg = db.prepare('SELECT * FROM pages WHERE user_id = ? AND page_id = ?').get(req.uid, pageId);
  if (!pg) return res.status(404).json({ error: 'Page not found' });
  if (pg.needs_reauth) return res.status(400).json({ error: 'This Page needs you to sign in again.' });
  const user = db.prepare('SELECT paused FROM users WHERE id = ?').get(req.uid);
  const t = now();
  let at = t;
  if (scheduledAt !== undefined && scheduledAt !== null) {
    if (!Number.isInteger(scheduledAt) || scheduledAt < t + 600) return res.status(400).json({ error: 'Pick a time at least 10 minutes from now, or publish now.' });
    if (scheduledAt > t + 365 * 86400) return res.status(400).json({ error: 'Schedule must be within one year.' });
    at = scheduledAt;
  } else if (user.paused) {
    return res.status(409).json({ error: 'Publishing is paused. Turn the pause off first.' });
  }
  const id = db.prepare("INSERT INTO posts(user_id, page_id, message, scheduled_at, status, created_at, updated_at) VALUES(?,?,?,?, 'queued', ?, ?)")
    .run(req.uid, pageId, message.trim(), at, t, t).lastInsertRowid;
  audit(req.uid, 'post_created', `post ${id} page ${pageId}${at > t ? ' scheduled ' + at : ' now'}`);
  if (at === t) await processPost(Number(id));
  res.json({ post: pubPost(db.prepare('SELECT * FROM posts WHERE id = ?').get(id)) });
}));

app.get('/posts', auth, (req, res) => {
  const pageId = req.query.pageId ? String(req.query.pageId) : null;
  const rows = pageId
    ? db.prepare('SELECT * FROM posts WHERE user_id = ? AND page_id = ? ORDER BY id DESC LIMIT 30').all(req.uid, pageId)
    : db.prepare('SELECT * FROM posts WHERE user_id = ? ORDER BY id DESC LIMIT 30').all(req.uid);
  res.json({ posts: rows.map(pubPost) });
});

app.post('/posts/:id/cancel', auth, ah(async (req, res) => {
  const p = db.prepare('SELECT * FROM posts WHERE id = ? AND user_id = ?').get(req.params.id, req.uid);
  if (!p) return res.status(404).json({ error: 'Post not found' });
  if (!['queued', 'scheduled'].includes(p.status)) return res.status(409).json({ error: 'Only queued or scheduled posts can be cancelled.' });
  if (p.status === 'scheduled' && p.fb_post_id) {
    const pg = db.prepare('SELECT * FROM pages WHERE user_id = ? AND page_id = ?').get(req.uid, p.page_id);
    if (pg) {
      try { await meta.deletePost(p.fb_post_id, dec(pg.token)); }
      catch (e) { return res.status(502).json({ error: 'Could not cancel at Meta: ' + e.message }); }
    }
  }
  db.prepare("UPDATE posts SET status='cancelled', updated_at=? WHERE id=?").run(now(), p.id);
  audit(req.uid, 'post_cancelled', `post ${p.id}`);
  res.json({ ok: true });
}));

// ---------- Pause ----------
app.get('/pause', auth, (req, res) => {
  res.json({ paused: !!db.prepare('SELECT paused FROM users WHERE id = ?').get(req.uid).paused });
});

app.post('/pause', auth, ah(async (req, res) => {
  const on = !!(req.body && req.body.paused);
  db.prepare('UPDATE users SET paused = ? WHERE id = ?').run(on ? 1 : 0, req.uid);
  audit(req.uid, on ? 'paused' : 'resumed', null);
  let note = on ? 'Paused.' : 'Resumed.';
  if (on) {
    const sched = db.prepare("SELECT * FROM posts WHERE user_id = ? AND status = 'scheduled' AND fb_post_id IS NOT NULL").all(req.uid);
    let back = 0, stuck = 0;
    for (const p of sched) {
      const pg = db.prepare('SELECT * FROM pages WHERE user_id = ? AND page_id = ?').get(req.uid, p.page_id);
      try {
        await meta.deletePost(p.fb_post_id, dec(pg.token));
        db.prepare("UPDATE posts SET status='queued', fb_post_id=NULL, attempts=0, next_attempt_at=0, error='Paused: held in the queue', updated_at=? WHERE id=?").run(now(), p.id);
        back++;
      } catch (e) {
        db.prepare('UPDATE posts SET error=?, updated_at=? WHERE id=?').run('Pause could not cancel this at Meta; it may still publish. ' + e.message, now(), p.id);
        stuck++;
      }
    }
    note = `Paused. ${back} scheduled post(s) pulled back from Meta.` + (stuck ? ` ${stuck} could not be cancelled and may still publish.` : '');
  } else {
    note = `Resumed. Posts whose time passed more than ${Math.round(GRACE / 60)} min ago will be marked failed instead of published late.`;
  }
  res.json({ paused: on, note });
}));

// ---------- Account / audit ----------
app.delete('/account', auth, ah(async (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(req.uid);
  const pages = db.prepare('SELECT * FROM pages WHERE user_id = ?').all(req.uid);
  const sched = db.prepare("SELECT * FROM posts WHERE user_id = ? AND status = 'scheduled' AND fb_post_id IS NOT NULL").all(req.uid);
  const r = await cancelScheduledAtMeta(sched, (pid) => dec(pages.find((x) => x.page_id === pid).token));
  let revoked = false;
  try { await meta.revoke(u.fb_user_id, dec(u.user_token)); revoked = true; } catch (e) { /* reported below */ }
  db.transaction(() => {
    for (const t of ['sessions', 'pages', 'posts']) db.prepare(`DELETE FROM ${t} WHERE user_id = ?`).run(req.uid);
    db.prepare('DELETE FROM users WHERE id = ?').run(req.uid);
  })();
  audit(null, 'account_disconnected', `fb user ${u.fb_user_id}, revoked=${revoked}`);
  res.json({ ok: true, revoked, couldNotCancel: r.failed });
}));

app.get('/audit', auth, (req, res) => {
  res.json({ entries: db.prepare('SELECT action, detail, at FROM audit WHERE user_id = ? ORDER BY id DESC LIMIT 50').all(req.uid) });
});

// ---------- Publishing worker ----------
function failPost(p, msg) {
  db.prepare("UPDATE posts SET status='failed', error=?, updated_at=? WHERE id=?").run(msg, now(), p.id);
  audit(p.user_id, 'post_failed', `post ${p.id}: ${msg}`);
}

async function processPost(id) {
  const p = db.prepare('SELECT * FROM posts WHERE id = ?').get(id);
  if (!p || p.status !== 'queued') return;
  const user = db.prepare('SELECT paused FROM users WHERE id = ?').get(p.user_id);
  if (!user || user.paused) return;
  const pg = db.prepare('SELECT * FROM pages WHERE user_id = ? AND page_id = ?').get(p.user_id, p.page_id);
  if (!pg || pg.needs_reauth) return failPost(p, 'This Page is disconnected or needs you to sign in again.');
  const t = now();
  const remaining = p.scheduled_at - t;
  let when = null;
  if (p.attempts === 0 && remaining < -GRACE) return failPost(p, 'Missed its scheduled time (server was paused or offline). Schedule it again if you still want it.');
  if (remaining >= NATIVE_MIN) {
    if (remaining > HANDOFF) return; // too early: keep holding
    when = p.scheduled_at;            // hand to Meta's native scheduler
  } else if (remaining > 0) {
    return;                           // under Meta's 10 min minimum: publish when due
  }
  const claim = db.prepare("UPDATE posts SET status='sending', updated_at=? WHERE id=? AND status='queued'").run(t, id);
  if (claim.changes !== 1) return;
  try {
    const r = await meta.publish(p.page_id, dec(pg.token), p.message, when);
    db.prepare('UPDATE posts SET status=?, fb_post_id=?, error=NULL, attempts=attempts+1, updated_at=? WHERE id=?').run(when ? 'scheduled' : 'published', r.id || null, now(), id);
    audit(p.user_id, when ? 'post_scheduled' : 'post_published', `post ${id} -> ${r.id}`);
  } catch (e) {
    const isMeta = e instanceof meta.MetaError;
    const attempts = p.attempts + 1;
    if (isMeta && e.code === 190) db.prepare('UPDATE pages SET needs_reauth=1 WHERE user_id=? AND page_id=?').run(p.user_id, p.page_id);
    if (isMeta && e.transient && attempts < MAX_ATTEMPTS) {
      const delay = Math.min(60 * 2 ** attempts, 3600) + Math.floor(Math.random() * 30);
      db.prepare("UPDATE posts SET status='queued', attempts=?, next_attempt_at=?, error=?, updated_at=? WHERE id=?")
        .run(attempts, now() + delay, `${e.message} (retry ${attempts}/${MAX_ATTEMPTS - 1})`, now(), id);
    } else {
      db.prepare('UPDATE posts SET attempts=? WHERE id=?').run(attempts, id);
      failPost(p, isMeta ? e.message : 'Unexpected server error while publishing.');
    }
  }
}

// Confirms natively scheduled posts actually went out.
async function reconcile(t) {
  const rows = db.prepare("SELECT * FROM posts WHERE status='scheduled' AND fb_post_id IS NOT NULL AND scheduled_at <= ? LIMIT 20").all(t - 120);
  for (const p of rows) {
    const pg = db.prepare('SELECT * FROM pages WHERE user_id = ? AND page_id = ?').get(p.user_id, p.page_id);
    if (!pg) continue;
    try {
      const r = await meta.getPost(p.fb_post_id, dec(pg.token));
      if (r.is_published) {
        db.prepare("UPDATE posts SET status='published', permalink=?, updated_at=? WHERE id=?").run(r.permalink_url || null, now(), p.id);
        audit(p.user_id, 'post_published', `post ${p.id} (scheduled at Meta)`);
      } else if (t - p.scheduled_at > 3600) {
        failPost(p, 'Meta did not publish this post at its scheduled time.');
      }
    } catch (e) {
      if (e instanceof meta.MetaError && !e.transient) failPost(p, 'Could not confirm this post at Meta (it may have been deleted): ' + e.message);
    }
  }
}

let busy = false;
async function tick() {
  if (busy) return;
  busy = true;
  try {
    const t = now();
    const due = db.prepare("SELECT id FROM posts WHERE status='queued' AND next_attempt_at <= ? AND scheduled_at <= ? ORDER BY scheduled_at LIMIT 20").all(t, t + HANDOFF);
    for (const r of due) await processPost(r.id);
    await reconcile(t);
  } catch (e) {
    console.error('worker error:', e.message);
  } finally {
    busy = false;
  }
}

// A crash mid-send is ambiguous (Meta may have created the post), so never auto-retry it.
db.prepare("UPDATE posts SET status='failed', error='The server restarted while sending. Check your Page to see whether this post went out.' WHERE status='sending'").run();
setInterval(tick, 30000);
setTimeout(tick, 5000);

app.use((err, req, res, next) => {
  console.error('error:', err.message);
  res.status(500).json({ error: 'Server error. Please try again.' });
});

app.listen(process.env.PORT || 3000, () => console.log('Backend listening'));

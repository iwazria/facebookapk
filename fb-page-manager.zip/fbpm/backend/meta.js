'use strict';
const crypto = require('crypto');

const V = process.env.GRAPH_VERSION || 'v25.0';
const APP_ID = process.env.META_APP_ID;
const APP_SECRET = process.env.META_APP_SECRET;
const G = `https://graph.facebook.com/${V}`;

class MetaError extends Error {
  constructor(message, o = {}) {
    super(message);
    this.code = o.code;
    this.transient = !!o.transient;
  }
}

const proof = (token) => crypto.createHmac('sha256', APP_SECRET).update(token).digest('hex');

// Turns a Graph API error into a readable message + a retry decision.
function fromError(e, status) {
  const code = e.code;
  const transient = !!e.is_transient || status >= 500 || [1, 2, 4, 17, 32, 341, 613].includes(code);
  let msg;
  if (code === 190) msg = 'Meta says the login for this Page expired or was revoked. Sign out and sign in again to reconnect.';
  else if ([4, 17, 32, 613].includes(code)) msg = 'Meta rate limit reached. The app will retry later.';
  else if ([1, 2].includes(code) || status >= 500) msg = 'Meta had a temporary problem. The app will retry.';
  else if (code === 10 || (code >= 200 && code < 300)) msg = 'Meta denied permission. Check that you can create content on this Page and that the app has the pages_manage_posts permission.';
  else if (code === 368) msg = 'Meta temporarily blocked posting from this Page for policy reasons. Check the Page in Facebook.';
  else if (code === 100) msg = 'Meta rejected the request: ' + (e.message || 'invalid parameter');
  else msg = `Meta error${code ? ' (' + code + ')' : ''}: ${e.message || 'unknown error'}`;
  return new MetaError(msg, { code, transient });
}

async function graph(method, path, { token, params = {} } = {}) {
  const p = new URLSearchParams(params);
  if (token) { p.set('access_token', token); p.set('appsecret_proof', proof(token)); }
  let url = G + path;
  const opts = { method, signal: AbortSignal.timeout(30000) };
  if (method === 'POST') {
    opts.body = p;
    opts.headers = { 'Content-Type': 'application/x-www-form-urlencoded' };
  } else {
    url += '?' + p.toString();
  }
  let res;
  try { res = await fetch(url, opts); }
  catch (e) { throw new MetaError('Network problem reaching Meta. The app will retry.', { transient: true }); }
  let j = {};
  try { j = await res.json(); } catch (e) { /* non-JSON body */ }
  if (!res.ok || j.error) throw fromError(j.error || {}, res.status);
  return j;
}

const exchangeCode = (code, redirectUri) => graph('GET', '/oauth/access_token', { params: { client_id: APP_ID, client_secret: APP_SECRET, redirect_uri: redirectUri, code } });
const longLived = (t) => graph('GET', '/oauth/access_token', { params: { grant_type: 'fb_exchange_token', client_id: APP_ID, client_secret: APP_SECRET, fb_exchange_token: t } });
const me = (t) => graph('GET', '/me', { token: t, params: { fields: 'id,name' } });

async function listPages(t) {
  let out = [];
  let after = null;
  do {
    const params = { fields: 'id,name,access_token,tasks', limit: '100' };
    if (after) params.after = after;
    const j = await graph('GET', '/me/accounts', { token: t, params });
    out = out.concat(j.data || []);
    after = j.paging && j.paging.next && j.paging.cursors ? j.paging.cursors.after : null;
  } while (after);
  return out;
}

// when = unix seconds (Meta native scheduling) or null (publish now)
const publish = (pageId, token, message, when) => graph('POST', `/${pageId}/feed`, {
  token,
  params: when ? { message, published: 'false', scheduled_publish_time: String(when) } : { message },
});
const getPost = (id, token) => graph('GET', `/${id}`, { token, params: { fields: 'is_published,permalink_url,scheduled_publish_time' } });
const deletePost = (id, token) => graph('DELETE', `/${id}`, { token });
const revoke = (fbUserId, userToken) => graph('DELETE', `/${fbUserId}/permissions`, { token: userToken });

module.exports = { MetaError, exchangeCode, longLived, me, listPages, publish, getPost, deletePost, revoke, V };

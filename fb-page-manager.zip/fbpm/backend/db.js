'use strict';
const Database = require('better-sqlite3');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const dbPath = process.env.DB_PATH || path.join(__dirname, 'data', 'app.db');
fs.mkdirSync(path.dirname(dbPath), { recursive: true });
const db = new Database(dbPath);
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, fb_user_id TEXT UNIQUE NOT NULL, name TEXT, user_token TEXT, paused INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS pages(user_id INTEGER NOT NULL, page_id TEXT NOT NULL, name TEXT, token TEXT, needs_reauth INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(user_id, page_id));
CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS oauth_state(state TEXT PRIMARY KEY, challenge TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS app_codes(code_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL, challenge TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, page_id TEXT NOT NULL, message TEXT NOT NULL, scheduled_at INTEGER NOT NULL, status TEXT NOT NULL, fb_post_id TEXT, permalink TEXT, error TEXT, attempts INTEGER NOT NULL DEFAULT 0, next_attempt_at INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, user_id INTEGER, action TEXT NOT NULL, detail TEXT, at INTEGER NOT NULL);
`);

const KEY = Buffer.from(process.env.TOKEN_ENC_KEY || '', 'base64');
if (KEY.length !== 32) throw new Error('TOKEN_ENC_KEY must be 32 random bytes, base64-encoded');

// AES-256-GCM. Stored as iv.tag.ciphertext (all base64).
function enc(plain) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', KEY, iv);
  const ct = Buffer.concat([c.update(plain, 'utf8'), c.final()]);
  return [iv, c.getAuthTag(), ct].map((b) => b.toString('base64')).join('.');
}
function dec(s) {
  const [iv, tag, ct] = s.split('.').map((x) => Buffer.from(x, 'base64'));
  const d = crypto.createDecipheriv('aes-256-gcm', KEY, iv);
  d.setAuthTag(tag);
  return Buffer.concat([d.update(ct), d.final()]).toString('utf8');
}
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
const now = () => Math.floor(Date.now() / 1000);
function audit(userId, action, detail) {
  db.prepare('INSERT INTO audit(user_id, action, detail, at) VALUES(?,?,?,?)')
    .run(userId || null, action, detail ? String(detail).slice(0, 500) : null, now());
}

module.exports = { db, enc, dec, sha, now, audit };

package com.example.fbpagemgr;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.format.DateFormat;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    interface Work { JSONObject run() throws Exception; }
    interface Done { void ok(JSONObject r); }

    private final ExecutorService ex = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Store store;
    private String base, session;
    private LinearLayout box;
    private final List<String> pageIds = new ArrayList<>();
    private final List<String> pageNames = new ArrayList<>();
    private Calendar when;
    private Spinner spinner;
    private EditText msg;
    private TextView whenLbl;
    private LinearLayout postsBox;
    private Switch pauseSwitch;
    private boolean settingPause;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        store = new Store(this);
        base = store.get("base");
        session = store.getSecret("session");
        ScrollView sv = new ScrollView(this);
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        box.setPadding(pad, pad, pad, pad);
        sv.addView(box);
        setContentView(sv);
        if (handleIntent(getIntent())) return;
        if (session == null) showLogin(); else showMain();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        handleIntent(i);
    }

    // ---------- helpers ----------
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private TextView text(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setPadding(0, dp(6), 0, dp(6));
        box.addView(t);
        return t;
    }

    private void title(String s) {
        TextView t = text(s);
        t.setTextSize(22);
        t.setTypeface(null, Typeface.BOLD);
    }

    private Button btn(String s) {
        Button b = new Button(this);
        b.setText(s);
        box.addView(b);
        return b;
    }

    private void confirm(String q, final Runnable yes) {
        new AlertDialog.Builder(this)
                .setMessage(q)
                .setPositiveButton("Yes", (d, w) -> yes.run())
                .setNegativeButton("No", null)
                .show();
    }

    private void bg(final Work w, final Done d) {
        ex.execute(() -> {
            try {
                final JSONObject r = w.run();
                ui.post(() -> d.ok(r));
            } catch (final Exception e) {
                ui.post(() -> onError(e));
            }
        });
    }

    private JSONObject api(String method, String path, JSONObject body) throws Exception {
        return Api.request(method, base + path, session, body);
    }

    private void onError(Exception e) {
        if (e instanceof Api.AuthException) {
            signedOut();
            toast("Please sign in again.");
            return;
        }
        toast(e.getMessage() == null ? "Something went wrong" : e.getMessage());
    }

    private void signedOut() {
        store.remove("session");
        session = null;
        showLogin();
    }

    private String selectedPage() {
        if (spinner == null) return null;
        int i = spinner.getSelectedItemPosition();
        return (i >= 0 && i < pageIds.size()) ? pageIds.get(i) : null;
    }

    // ---------- sign-in ----------
    private void showLogin() {
        box.removeAllViews();
        title("Page Manager");
        text("Sign in with Meta's official login. Your Facebook password is only ever typed on Meta's own page, never in this app.");
        final EditText url = new EditText(this);
        url.setHint("Backend URL, e.g. https://my-backend.onrender.com");
        url.setSingleLine(true);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        if (base != null) url.setText(base);
        box.addView(url);
        Button go = btn("Connect with Facebook");
        go.setOnClickListener(v -> {
            String u = url.getText().toString().trim().replaceAll("/+$", "");
            if (!u.startsWith("https://")) { toast("The URL must start with https://"); return; }
            base = u;
            store.put("base", u);
            startLogin();
        });
    }

    private void startLogin() {
        try {
            byte[] r = new byte[32];
            new SecureRandom().nextBytes(r);
            int flags = Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING;
            String verifier = Base64.encodeToString(r, flags);
            byte[] h = MessageDigest.getInstance("SHA-256").digest(verifier.getBytes("US-ASCII"));
            String challenge = Base64.encodeToString(h, flags);
            store.put("verifier", verifier);
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(base + "/auth/start?challenge=" + challenge)));
        } catch (Exception e) {
            toast("Could not start sign-in: " + e.getMessage());
        }
    }

    private boolean handleIntent(Intent i) {
        Uri u = (i == null) ? null : i.getData();
        if (u == null || !"fbpagemgr".equals(u.getScheme())) return false;
        setIntent(new Intent());
        final String code = u.getQueryParameter("code");
        final String verifier = store.get("verifier");
        if (code == null || verifier == null || base == null) {
            toast("Sign-in did not complete. Please try again.");
            return false;
        }
        box.removeAllViews();
        text("Signing in…");
        bg(() -> Api.request("POST", base + "/auth/exchange", null, Api.obj("code", code, "verifier", verifier)), r -> {
            store.remove("verifier");
            String s = r.optString("session", "");
            if (s.isEmpty()) { toast("Sign-in failed"); showLogin(); return; }
            store.putSecret("session", s);
            session = s;
            showMain();
        });
        return true;
    }

    // ---------- main screen ----------
    private void showMain() {
        box.removeAllViews();
        title("Page Manager");
        text("Page");
        spinner = new Spinner(this);
        box.addView(spinner);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> a, View v, int pos, long id) { loadPosts(); }
            @Override public void onNothingSelected(AdapterView<?> a) { }
        });

        msg = new EditText(this);
        msg.setHint("Write your post…");
        msg.setMinLines(4);
        msg.setGravity(Gravity.TOP);
        msg.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        box.addView(msg);

        whenLbl = text("");
        refreshWhen();
        Button pick = btn("Pick date & time (optional)");
        pick.setOnClickListener(v -> pickWhen());
        Button clear = btn("Clear schedule (publish now)");
        clear.setOnClickListener(v -> { when = null; refreshWhen(); });
        Button go = btn("Publish / schedule");
        go.setOnClickListener(v -> submit());

        pauseSwitch = new Switch(this);
        pauseSwitch.setText("Pause all queued & scheduled publishing");
        pauseSwitch.setPadding(0, dp(12), 0, dp(12));
        box.addView(pauseSwitch);
        pauseSwitch.setOnCheckedChangeListener((cb, on) -> { if (!settingPause) setPause(on); });

        title("Recent posts");
        Button refresh = btn("Refresh");
        refresh.setOnClickListener(v -> loadPosts());
        postsBox = new LinearLayout(this);
        postsBox.setOrientation(LinearLayout.VERTICAL);
        box.addView(postsBox);

        Button dcPage = btn("Disconnect selected Page");
        dcPage.setOnClickListener(v -> disconnectPage());
        Button dcAcct = btn("Disconnect account (revoke access)");
        dcAcct.setOnClickListener(v -> confirm("Revoke this app's access at Meta and delete everything stored on the backend?", () ->
                bg(() -> api("DELETE", "/account", null), r -> {
                    toast(r.optBoolean("revoked") ? "Access revoked and data deleted." : "Data deleted, but Meta could not confirm revocation. Remove the app in Facebook > Settings > Business Integrations.");
                    signedOut();
                })));
        Button out = btn("Sign out");
        out.setOnClickListener(v -> {
            final String s = session;
            final String b = base;
            ex.execute(() -> { try { Api.request("POST", b + "/auth/logout", s, null); } catch (Exception ignored) { } });
            signedOut();
        });

        loadPages();
        loadPause();
    }

    private void refreshWhen() {
        if (whenLbl == null) return;
        if (when == null) whenLbl.setText("Will publish immediately.");
        else whenLbl.setText("Scheduled for: " + new SimpleDateFormat("EEE d MMM yyyy, HH:mm", Locale.getDefault()).format(when.getTime()));
    }

    private void pickWhen() {
        final Calendar start = Calendar.getInstance();
        start.add(Calendar.MINUTE, 30);
        new DatePickerDialog(this, (dpk, y, m, d) ->
                new TimePickerDialog(this, (tpk, h, mi) -> {
                    Calendar s = Calendar.getInstance();
                    s.set(y, m, d, h, mi, 0);
                    s.set(Calendar.MILLISECOND, 0);
                    when = s;
                    refreshWhen();
                }, start.get(Calendar.HOUR_OF_DAY), start.get(Calendar.MINUTE), DateFormat.is24HourFormat(this)).show(),
                start.get(Calendar.YEAR), start.get(Calendar.MONTH), start.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void loadPages() {
        bg(() -> api("GET", "/pages", null), r -> {
            JSONArray a = r.optJSONArray("pages");
            pageIds.clear();
            pageNames.clear();
            if (a != null) {
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.optJSONObject(i);
                    if (o == null) continue;
                    pageIds.add(o.optString("id"));
                    pageNames.add(o.optString("name") + (o.optBoolean("needsReauth") ? " (sign in again)" : ""));
                }
            }
            spinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, pageNames));
            if (pageIds.isEmpty()) toast("No Pages found. Sign out, sign in again and tick the Pages you manage.");
            loadPosts();
        });
    }

    private void loadPause() {
        bg(() -> api("GET", "/pause", null), r -> {
            settingPause = true;
            pauseSwitch.setChecked(r.optBoolean("paused"));
            settingPause = false;
        });
    }

    private void setPause(final boolean on) {
        bg(() -> api("POST", "/pause", Api.obj("paused", on)), r -> {
            toast(r.optString("note", on ? "Paused" : "Resumed"));
            loadPosts();
        });
    }

    private void submit() {
        final String pid = selectedPage();
        final String body = msg.getText().toString().trim();
        if (pid == null) { toast("Select a Page first."); return; }
        if (body.isEmpty()) { toast("Write something first."); return; }
        JSONObject req = Api.obj("pageId", pid, "message", body);
        if (when != null) {
            long at = when.getTimeInMillis() / 1000;
            if (at < System.currentTimeMillis() / 1000 + 600) {
                toast("Pick a time at least 10 minutes from now, or clear the schedule to publish now.");
                return;
            }
            try { req.put("scheduledAt", at); } catch (Exception ignored) { }
        }
        final JSONObject payload = req;
        bg(() -> api("POST", "/posts", payload), r -> {
            JSONObject p = r.optJSONObject("post");
            String st = p == null ? "" : p.optString("status");
            String err = p == null ? "" : p.optString("error", "");
            toast(statusLabel(st) + (err.isEmpty() || "null".equals(err) ? "" : ": " + err));
            if ("published".equals(st) || "scheduled".equals(st) || "queued".equals(st)) {
                msg.setText("");
                when = null;
                refreshWhen();
            }
            loadPosts();
        });
    }

    private void disconnectPage() {
        final String pid = selectedPage();
        if (pid == null) { toast("Select a Page first."); return; }
        confirm("Disconnect this Page? Its queued and scheduled posts will be cancelled and its stored token deleted.", () ->
                bg(() -> api("DELETE", "/pages/" + Uri.encode(pid), null), r -> {
                    toast(r.optString("note", "Disconnected"));
                    loadPages();
                }));
    }

    private void loadPosts() {
        final String pid = selectedPage();
        if (postsBox == null) return;
        if (pid == null) { postsBox.removeAllViews(); return; }
        bg(() -> api("GET", "/posts?pageId=" + Uri.encode(pid), null), r -> renderPosts(r.optJSONArray("posts")));
    }

    private String statusLabel(String s) {
        switch (s) {
            case "published": return "Published";
            case "scheduled": return "Scheduled at Meta";
            case "queued": return "Queued";
            case "failed": return "Failed";
            case "cancelled": return "Cancelled";
            case "sending": return "Sending";
            default: return s;
        }
    }

    private String statusColor(String s) {
        switch (s) {
            case "published": return "#2E7D32";
            case "failed": return "#C62828";
            case "scheduled": return "#1565C0";
            case "queued": return "#6A1B9A";
            default: return "#757575";
        }
    }

    private void renderPosts(JSONArray a) {
        postsBox.removeAllViews();
        if (a == null || a.length() == 0) {
            TextView t = new TextView(this);
            t.setText("No posts yet.");
            postsBox.addView(t);
            return;
        }
        SimpleDateFormat f = new SimpleDateFormat("EEE d MMM, HH:mm", Locale.getDefault());
        for (int i = 0; i < a.length(); i++) {
            final JSONObject p = a.optJSONObject(i);
            if (p == null) continue;
            final String st = p.optString("status");
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setPadding(0, dp(10), 0, dp(10));

            TextView head = new TextView(this);
            head.setText(statusLabel(st) + " · " + f.format(new Date(p.optLong("scheduledAt") * 1000)));
            head.setTextColor(Color.parseColor(statusColor(st)));
            head.setTypeface(null, Typeface.BOLD);
            item.addView(head);

            String m = p.optString("message");
            TextView body = new TextView(this);
            body.setText(m.length() > 160 ? m.substring(0, 160) + "…" : m);
            item.addView(body);

            String err = p.optString("error", "");
            if (!err.isEmpty() && !"null".equals(err)) {
                TextView e = new TextView(this);
                e.setText(err);
                e.setTextColor(Color.parseColor("#C62828"));
                item.addView(e);
            }
            final String link = p.optString("permalink", "");
            if (!link.isEmpty() && !"null".equals(link)) {
                TextView l = new TextView(this);
                l.setText("Open on Facebook");
                l.setTextColor(Color.parseColor("#1565C0"));
                l.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(link))));
                item.addView(l);
            }
            if ("queued".equals(st) || "scheduled".equals(st)) {
                Button c = new Button(this);
                c.setText("Cancel this post");
                c.setOnClickListener(v -> confirm("Cancel this post?", () ->
                        bg(() -> api("POST", "/posts/" + p.optLong("id") + "/cancel", new JSONObject()), r -> loadPosts())));
                item.addView(c);
            }
            postsBox.addView(item);
        }
    }
}
